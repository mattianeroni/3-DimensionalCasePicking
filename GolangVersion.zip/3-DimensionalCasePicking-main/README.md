# 3-DimensionalCasePicking

A new algorithm for the 3-Dimensional Case Picking Problem. A newly considered problem of operational research that combines the well-known case picking problem with the positioning of 3-dimensional items inside pallets (i.e., Pallet Loading Problem). 


The algorithm proposed and implemented comes from a collaboration between the Department of Engineering at University of Parma (Parma, ITALY) and the IN3 Computer Science Dept. at Universitat Oberta de Catalunya (Barcelona, SPAIN).

Paper link: https://it.overleaf.com/project/608ad8ed9d613074ae9cd2d7

![alt text](https://github.com/mattianeroni/3-DimensionalCasePicking/blob/main/pic.png)
