

import collections
import itertools
from math import log
import time
import random
import copy

class P:

    def __init__(self):
        self.a = 12
        self.b = [True, True, True]
        self.frozen = None

    def froze(self):
        self.frozen = dict(self.__dict__)

    def restore (self):
        self.__dict__.update(**self.frozen)
        self.frozen = True

    def __copy__(self):
        obj = P.__new__(self.__class__)
        obj.__dict__.update(self.__dict__)
        return obj

    def __repr__ (self):
        return f"< a={self.a}, b={self.b} >"



p = P()

#p.froze()
print(p)

g = copy.deepcopy(p)
g.b[0] = False



#p.restore()

print(p)
