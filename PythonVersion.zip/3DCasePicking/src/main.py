
import time
import operator
import random

import packing
import warehouse
import utils

from pallet import Pallet
from solver import Solver



if __name__ == "__main__":
	orderlines = utils.readfile("../test/testproblem.csv")
	dists = warehouse.distance_matrix
	edges = utils.get_edges(orderlines, dists)
	"""
	#cases = [c for o in orderlines for c in o.cases]
	p = Pallet()

	done, packedCases, _ = packing.dubePacker(p, orderlines[0].cases)
	print(done)
	p.cases = packedCases

	for case in p.cases:
		print(case.__dict__)
	utils.plot(p)
	"""

	solver = Solver(orderlines, edges, dists)

	start = time.time()
	sol = solver.getSolution(edges, orderlines)#__call__(maxtime=60)  #
	print(time.time() - start)
	print(len(sol))


	#print(cost)
	for pallet in sol:
		print("\n\n\n")
		for orderline in pallet.orderlines:
			for case in orderline.cases:
				print(case.__dict__)
		utils.plot(pallet)

	#	#print(pallet.layersMap)

	#solver.plot()
